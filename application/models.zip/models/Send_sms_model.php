<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Send_sms_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_send_sms';
		$this->primary_key = 'id';
	}
}