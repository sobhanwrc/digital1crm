<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Module7_Model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_module7';
		$this->primary_key='module_7_seq_no';
	}
}
