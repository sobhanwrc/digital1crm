<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Designation_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_designation';
		$this->primary_key = 'designatino_seq_no';
	}
}

