
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Signature_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_signature';
		$this->primary_key = 'signature_seq_no';
	}
}
?>