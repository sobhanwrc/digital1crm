<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Practice_area_survey_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = ' plma_pa_survey';
		$this->primary_key = 'pa_survey_seq_no';
	}
}

