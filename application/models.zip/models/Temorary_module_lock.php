<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Temorary_module_lock extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_temorary_module_lock';
//		$this->primary_key = 'target_seq_no';
	}
}
