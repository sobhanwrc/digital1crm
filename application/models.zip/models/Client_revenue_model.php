<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Client_revenue_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_client_revenue';
		$this->primary_key = 'id';
	}
}
