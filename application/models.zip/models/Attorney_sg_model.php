<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Attorney_sg_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_attorney_sg';
		$this->primary_key = 'asg_relation_seq_no';
	}
}