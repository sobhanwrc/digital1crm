<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Attorney_goals_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_attorney_goal';
		$this->primary_key = 'at_goal_seq_no';
	}
}

