<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Act_attorney_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_act_attorney';
		$this->primary_key = 'activity_attr_seq_no';
	}
}
