<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Comp_aty_rank_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_cmp_aty_rank';
		$this->primary_key = 'comp_att_rank_seq_no';
	}
}
