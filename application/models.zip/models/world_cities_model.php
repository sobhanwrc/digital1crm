<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class World_cities_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_world_cities';
		$this->primary_key = 'world_cities_seq_no';
	}
}
