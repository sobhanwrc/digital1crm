<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Super_user_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_super_user';
		$this->primary_key = 'id';
	}
}
