<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Target_attorney_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_tgt_attorney';
		$this->primary_key = 'tgt_attorney_seq_no';
	}
}

