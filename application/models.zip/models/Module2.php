<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Module2 extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_module2';
		$this->primary_key = 'id';
	}
}

