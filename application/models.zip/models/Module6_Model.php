<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Module6_Model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_module6';
		$this->primary_key = 'id';
	}
}
