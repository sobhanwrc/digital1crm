<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Approval_level_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_approval_level';
		$this->primary_key = 'approval_level_seq_no';
	}
}