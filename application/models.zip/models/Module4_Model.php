<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Module4_Model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_module4';
		$this->primary_key = 'module_4_seq_no';
	}
}
