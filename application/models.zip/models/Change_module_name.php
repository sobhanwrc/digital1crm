<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Change_module_name extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_change_module_name';
		$this->primary_key = 'id';
	}
}
