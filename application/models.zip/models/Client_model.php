<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Client_model extends MY_Model
{
	function __construct()
	{
		parent::__construct();
		$this->table = 'plma_client';
		$this->primary_key = 'client_seq_no';
	}
}
