<!DOCTYPE html>

<html lang="en">
    <!--<![endif]-->
    <!-- BEGIN HEAD -->

    <?php echo $header_link; ?>
    <!-- END HEAD -->
    <?php //print_r  ($categories); die(); ?>
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
        <div id="loader_image" style=" width: 100%; height: 800px; position: absolute; top: 0; left: 0; padding-top: 15%; text-align: center; overflow-y: hidden !important; overflow-x: hidden !important; background: #fff; z-index: 99999999999">
            <img style="width: 100px; height:100px" src="<?php echo $assets_path; ?>pages/img/Loading_icon.gif" alt="" class="" />

        </div>
        <!-- BEGIN HEADER -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="menu-toggler sidebar-toggler"> </div>
            <!-- BEGIN HEADER INNER -->
            <?php echo $header; ?>
            <!-- END HEADER INNER -->
        </div><!-- END HEADER -->
        <!-- BEGIN HEADER & CONTENT DIVIDER -->
        <div class="clearfix"> </div>
        <!-- END HEADER & CONTENT DIVIDER -->
        <!-- BEGIN CONTAINER -->
        <div class="page-container">
            <!-- BEGIN SIDEBAR -->
            <?php echo $left_sidebar; ?>
            <!-- END SIDEBAR -->
            <!-- BEGIN CONTENT -->
            <div class="page-content-wrapper">
                <!-- BEGIN CONTENT BODY -->
                <div class="page-content">
                    <!-- BEGIN PAGE HEADER-->

                    <!-- BEGIN PAGE BAR -->
                    <?php //echo $breadcrumb; ?>
                    <div class="page-bar">
                        <ul class="page-breadcrumb">
                            <li>
                                <a href="<?php echo base_url() ?>dashboard">Home</a>
                                <i class="fa fa-circle"></i>
                            </li>
                            <!-- <li>
                                 <a href="#">Manage Call User</a>
                                 <i class="fa fa-circle"></i> 
                             </li> -->
                            <li>
                                <span>Search From Contact List</span>
                            </li>
                        </ul>

                    </div>
                    <!-- END PAGE BAR -->

                    <!-- END PAGE HEADER-->
                    <div class="row">
                        <div class="col-md-12">
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <!-- BEGIN EXAMPLE TABLE PORTLET-->
                            <div class="portlet light bordered">
                                <div class="portlet-title">
                                    <div class="caption font-dark">
                                        <i class="icon-settings font-dark"></i>
                                        <span class="caption-subject bold uppercase">Search From Contact List</span>
                                    </div>

                                </div>
                                <div class="portlet-body">                                   
                                    <table class="table table-striped table-bordered table-hover table-responsive" id="search_contact_table1">
                                        <thead>
                                            <tr class="">
                                                <th> SL# </th>
                                                <th> Name </th>
                                                <th> Email </th>
                                                <th> Industry Name </th>
                                                <th> Industry  Type </th>
                                                <th> Phone Number </th>
                                                <th> 
                                                    <div class="cBox cBox-teal cBox-inline" style="width:35px;height: 25px ">
                                                        <div style="width: 20px; float: left;">
                                                            <input type="checkbox" value="all" name="all" id="examplecBox0" class="myCheckbox">
                                                            <label for="examplecBox0"></label>
                                                        </div>

                                                        <div style="width: 15px; float: left;">
                                                            <button type="button" class="dropdown-toggle" data-toggle="dropdown" style=" background:  transparent; border: none"><span class="caret"></span></button>
                                                            <ul class="dropdown-menu media-list" role="menu">
                                                                <li class="p15 pb10">
                                                                    <ul class="list-unstyled">
                                                                        <li id="all_item">All</li>
                                                                        <li class="pt10" id="f_5">First 5</li>
                                                                        <li class="pt10" id="f_10">First 10</li>
                                                                    </ul>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                            $i = 0;
                                            foreach ($firms as $key => $value) {
                                                ?>
                                                <tr>
                                                    <td> <?php echo ++$i; ?> </td>
                                                    <?php if ($role_code == 'SITEADM') { ?>
                                                        <td> <?php echo $value['firm_name']; ?> </td>
                                                    <?php } ?>
                                                    <td> <?php echo $value['target_first_name'].' '.$value['target_last_name']; ?></td>
            <!--                                        <td> <?php //if($value['attorney_gender'] == '122'){ echo 'Male'; }else if($value['attorney_gender'] == '123') { echo 'Female'; } else if($value['attorney_gender'] == '124') { echo 'Other'; }     ?> </td>-->
                                                    <td> <?php echo $value['email']; ?> </td>
                                                    <td> <?php echo $value['company']; ?> </td><!--
                                                    <td> <?php //echo $value['bar_registration_no'];     ?> </td>-->
                                                    <td> <?php echo $value['type']; ?> </td>
                                                    <td> <?php echo $value['phone']; ?> </td>
                                                    <!-- <td> <?php echo $value['position']; ?> </td>   -->                                     
                                                    <td>
                                                        <!--<input style="margin-left: 40px;" class="selected_contact" type="checkbox" name="checked_ids[]" value="<?php echo $value['target_seq_no']; ?>">--> 
                                                    
                                                        <div class="cBox cBox-teal cBox-inline">
                                                            <input type="checkbox" value="<?php echo $value['target_seq_no'];?>" name="checked_ids[]" id="examplecBox" class="myCheckbox">
                                                            <label for="examplecBox"></label>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php } ?>                                             

                                        </tbody>
                                    </table>
                                    <button style="margin-right: 4px;" id="assign_to_list" type="button" class="btn btn-transparent dark btn-outline btn-circle active" data-toggle="modal" data-target="#assign_to_list_modal" id="add_new">Assign To List</button>

                                </div>
                            </div>
                            <!-- END EXAMPLE TABLE PORTLET-->
                            <!-- END EXAMPLE TABLE PORTLET-->
                        </div>
                    </div>
                </div>
                <!-- END CONTENT BODY -->
            </div>
            <!-- END CONTENT -->
            <!-- BEGIN QUICK SIDEBAR -->


            <!-- END QUICK SIDEBAR -->

        </div>

        <div id="assign_to_list_modal" class="modal fade" role="dialog">

            <div class="modal-dialog modal-dialog-sm">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <div class="modal-title"><span style=" color:#333" class="glyphicon glyphicon-pencil text-purple2 mr10"></span><b style=" color:#333">Assign to list</b></div>
                    </div>
                    <div class="modal-body">
                        <div id="create_event" class=" mt10">
                            <div class="col-md-12">
                                <form name="assign_to_list_form" id="assign_to_list_form" method="POST" enctype="multipart/form-data">
                                    <div class="form-group" style=" color:#333">
                                        <div style="width: 16%; padding-top: 5px; display: inline-block">
                                            <label>Select a list</label>
                                        </div>
                                        <div style="width: 80%; display: inline-block">
                                            <select id="list_select" class="form-control" name="list_id">
                                                <option value="">Select List</option>
                                                <?php foreach ($managelist as $key => $value) { ?>
                                                    <option value="<?php echo $value['list_id']; ?>"><?php echo $value['list_name']; ?></option>
                                                <?php } ?> 
                                            </select>
                                        </div>

                                    </div>
                                    <div class=" col-md-12">
                                        <input style=" color:#fff" type="button" value="Submit" class="submit btn green pull-right" name="submit1" id="assign_list_submit" >
                                    </div>  
                                </form>
                            </div>
                        </div>
                        <div class="clearfix"></div>

                    </div>
                </div>
                <div class="modal-footer">
                    <div class="input-group col-md-12 pull-right" style="padding-left:10px">
                        <div id="master_name_submit_loader" style="display:none; padding-left:10px;"><font color="green"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END CONTAINER -->
        <!-- BEGIN FOOTER -->
        <?php echo $footer; ?>
        <!-- END FOOTER -->
        <?php echo $footer_link; ?>
        <style>
            .dropdown-menu {
                box-shadow: 5px 5px rgba(102,102,102,.1);
                left: -109px;
                min-width: 175px;
                position: absolute;
                z-index: 1000;
                display: none;
                float: left;
                list-style: none;
                padding: 0;
                background-color: #fff;
                margin: 10px 0 0;
                border: 1px solid #eee;
                font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
                -webkit-border-radius: 4px;
                -moz-border-radius: 4px;
                -ms-border-radius: 4px;
                -o-border-radius: 4px;
                border-radius: 4px;
            }

            .btn-group > .dropdown-menu::after, .dropdown-toggle > .dropdown-menu::after, .dropdown > .dropdown-menu::after {
                position: absolute;
                top: -7px;
                right: 10px !important;
                left: auto;
                display: inline-block !important;
                border-right: 7px solid transparent;
                border-bottom: 7px solid #fff;
                border-left: 7px solid transparent;
                content: '';
            }

            .btn-group > .dropdown-menu::before, .dropdown-toggle > .dropdown-menu::before, .dropdown > .dropdown-menu::before {
                position: absolute;
                top: -8px;
                right: 7px;
                left:auto;
                display: inline-block !important;
                border-right: 8px solid transparent;
                border-bottom: 8px solid #e0e0e0;
                border-left: 8px solid transparent;
                content: '';
            }
			

        </style>
        <script src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
        <script src="http://localhost/digital1crm/assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        
        <script src="http://localhost/digital1crm/assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="http://localhost/digital1crm/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <script src="http://localhost/digital1crm/assets/pages/scripts/table-datatables-responsive.js" type="text/javascript"></script>

        <script type="text/javascript">
            $(window).load(function() {
        //          $("#loader_image").hide();
                    $('#loader_image').delay(2000).fadeOut(1000)
            });

            jQuery(document).ready(function () {
                
                $('#examplecBox0').on('click', function () {
                    if ($("#examplecBox0").prop('checked') == true) {
                        $('.myCheckbox').prop('checked', true);
                    } else {
                        $('.myCheckbox').prop('checked', false);
                    }

                });

                $('#all_item').on('click', function () {
                    $('.myCheckbox').prop('checked', true);
                });
                $("#f_5").on("click", function () {
                    $('.myCheckbox').prop('checked', false);
                    var checkBoxes = $("#datatable1 tr td :checkbox:lt(5)");//using :lt get first 5 checkboxes
                    $(checkBoxes).prop("checked", !checkBoxes.prop("checked"));//change checkbox status based on check/uncheck
                });

                $("#f_10").on("click", function () {
                    $('.myCheckbox').prop('checked', false);
                    var checkBoxes = $("#datatable1 tr td :checkbox:lt(10)");//using :lt get first 5 checkboxes
                    $(checkBoxes).prop("checked", !checkBoxes.prop("checked"));//change checkbox status based on check/uncheck
                });

                //---------------------VALIDATE ASSIGN TO LIST FORM---------------------//
                $('#assign_to_list_form').validate({
                        rules: {
                            list_id: {
                                required: true
                            }
                        },
                        messages: {
                            list_id: {
                                required: "<font color=\"red\">Please select a list</font>",
                            }
                        }
                    });
                //---------END----------------//

                //------------- contacts assign to list ajax-----------------------//
                $("#assign_list_submit").click(function (e) {
                    var list_id = $('#list_select').val();
                    var checked_ids = [];
                    $("input[name='checked_ids[]']:checked").each(function (i) {               
                        checked_ids[i] = $(this).val();            
                    });            
                    checked_ids = JSON.stringify(checked_ids);            
                    checked_ids = JSON.parse(checked_ids);
                    var valid = $("#assign_to_list_form").valid();
                    if(valid){
                        $.ajax({
                            type: "POST",
                            url: BASE_URL + "managelist/assign_to_list/",
                            data: {
                                list_id: list_id,
                                checked_ids: checked_ids
                            },
                            success: function (data) {
                                if (data == 1) {
                                    jconfirm({
                                        title: 'Confirmation!',
                                        content: "Succesfully assigned to selected list",
                                        buttons: {
                                            OK: function () {
                                                window.location.href = BASE_URL + 'managelist';
                                                //   $('#add_category1').prop('disabled', true);
                                            }
                                        }
                                    });
                                } else {
                                    jconfirm({
                                        title: 'Alert!',
                                        content: "First select a contact to assign",
                                        buttons: {
                                            OK: function () {
                                                //window.location.href = BASE_URL + 'managelist/search_from_contacts';
                                                //   $('#add_category1').prop('disabled', true);
                                            }
                                        }
                                    });
                                }
                                
                            }

                        });
                    }
                });
                //-------------------end----------------------//
            });
        </script>
    </body>

</html> 